Friday mono Font
=======================

This download contains Friday mono.
You can download all formats of font from converted file Fridaymono_alltypes.zip



License
-------
This font is licensed under SIL Open Font License. Please read the full license text (OFL.txt) to understand the permissions, restrictions and requirements for usage, redistribution, and modification.


